"use client";

import { Button } from "@relume_io/relume-ui";
import React from "react";

export function Header71() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="flex flex-col">
          <div className="rb-12 mb-12 md:mb-18 lg:mb-20">
            <div className="w-full max-w-lg">
              <h1 className="mb-5 text-6xl font-bold md:mb-6 md:text-9xl lg:text-10xl">
                1000 Series Vinyl Siding in Sacramento, CA
              </h1>
              <p className="md:text-md">
                Experience the perfect blend of value, classic appeal, and
                durability for your home.
              </p>
              <div className="mt-6 flex flex-wrap gap-4 md:mt-8">
                <Button title="Schedule">Schedule</Button>
                <Button title="Estimate" variant="secondary">
                  Estimate
                </Button>
              </div>
            </div>
          </div>
          <div>
            <img
              src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image-landscape.svg"
              className="size-full rounded-image object-cover"
              alt="Relume placeholder image"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
